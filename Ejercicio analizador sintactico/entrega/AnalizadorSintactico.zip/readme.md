# Analizador sintáctico gráfico

Proyecto académico implementado en **C11**, con interfaz gráfica nativa **Win32**, para reconocer un lenguaje educativo llamado **MiniLenguaje** mediante descenso recursivo.

## Ejecutar

En Windows de 64 bits, abre `dist/AnalizadorSintactico.exe` con doble clic. No requiere GCC para ejecutarse y no abre una consola. El código escrito se analiza, no se ejecuta.

1. Escribe o pega un programa en el editor.
2. Pulsa **Analizar**.
3. Consulta las sentencias reconocidas y el resultado. Ante un error, se muestra su línea y columna; los errores sintácticos indican qué se esperaba y qué se encontró.
4. Usa **Limpiar** y el menú **Ayuda** para la demostración. El editor se abre vacío; puedes pegar los archivos de `ejemplos/`.

## Documentación y entrega

- [Lenguaje, gramática y límites](docs/LENGUAJE.md).
- [Casos de prueba y resultados esperados](docs/PRUEBAS.md).
- [Guía para presentar en clase](docs/EXPOSICION.md).
- `ejemplos/`: programas para copiar y pegar en la aplicación.
- `main.c`: código fuente del analizador y la interfaz.
- `compilar.bat`: construye y abre la aplicación; requiere GCC MinGW-w64. Detecta también la instalación de MSYS2 en `C:\msys64\ucrt64\bin`.
- `tests/pruebas.c` y `probar.bat`: verificación automática del analizador para desarrollo.
- `dist/AnalizadorSintactico.exe`: aplicación gráfica compilada.

Los scripts de compilación y pruebas usan la terminal como herramientas de desarrollo; el programa entregado funciona enteramente mediante ventanas. GitHub queda fuera de esta entrega por indicación del autor.

## Organización del código

`leerToken` identifica palabras, números y símbolos; `siguiente` detecta errores léxicos. `sentencia` reconoce declaraciones, asignaciones, print, if y while. Las funciones `expresion`, `comparacion`, `suma`, `producto`, `unario` y `primario` comprueban las expresiones respetando la precedencia. `bloque` reconoce llaves y sentencias anidadas. `analizarCodigo` coordina el análisis y presenta el resultado. `procedimientoVentana` procesa los botones y menús.

El analizador se detiene en el primer error. No construye un árbol sintáctico, no interpreta instrucciones y no realiza análisis semántico.
